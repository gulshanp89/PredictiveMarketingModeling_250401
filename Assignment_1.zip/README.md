# Assignment 1

Upload both files in the same GitHub folder/repository:

1. Assignment_1.ipynb
2. data.csv

Do not rename data.csv because the notebook reads `pd.read_csv("data.csv")`.
